%dtmfdesign.m

function hh = dtmfdesign(fcent, L, fs)
%DTMFDESIGN
% hh = dtmfdesign(fcent, L, fs)
% returns a matrix (L by length(fcent)) where each
% column contains the impulse response of a BPF, one
% for each frequency in fcent
% fcent = vector of center frequencies
% L = length of FIR bandpass filters
% fs = sampling freq
%
% Each BPF must be scaled so that its frequency response has a
% maximum magnitude equal to one.

nn = 0:L-1; % set n based on L
ww = 0:pi/300:pi; % create matrix of frequencies for finding B

for ii = 1:length(fcent) % loops through each inputted frequency
    hu(ii,:) = cos(2*pi*fcent(ii)*nn/fs); % simple band pass filter
    B(ii,:) = abs(1/(max( freqz(hu(ii,:),1,ww)))); 
    % finds vector of scaling coeffecients
    ha(ii,:) = hu(ii,:)*B(ii,:); % finishes filter by scaling each.
end

hh = ha'; % transposes matrix to put filters in columns