function y=signal_to_digit(signal)
n=100;                                         % Filter Order
fs=8000;

wn1=[0.17 0.18];
b1=fir1(n,wn1);

wn2=[0.1875 0.1975];
b2=fir1(n,wn2);

wn3=[0.2075 0.2175];
b3=fir1(n,wn3);

wn4=[0.23 0.24];
b4=fir1(n,wn4);

wn5=[0.2975 0.3025];
b5=fir1(n,wn5);

wn6=[0.3287 0.3388];
b6=fir1(n,wn6);

wn7=[0.3638 0.3738];
b7=fir1(n,wn7);

wn8=[0.4038 0.4138];
b8=fir1(n,wn8);

z1=filter(b1,1,signal);
z2=filter(b2,1,signal);
z3=filter(b3,1,signal);
z4=filter(b4,1,signal);
z5=filter(b5,1,signal);
z6=filter(b6,1,signal);
z7=filter(b7,1,signal);
z8=filter(b8,1,signal);

c=[sum(z1.^2) sum(z2.^2) sum(z3.^2) sum(z4.^2) sum(z5.^2) sum(z6.^2)...
    sum(z7.^2) sum(z8.^2)];
    
ir=find(c==max(c(1:4)));
ic=find(c==max(c(5:8)))-4;

y=[ir ic];
