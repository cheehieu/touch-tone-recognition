function [str] = realTimeMic2(duration, nBlocks)
% This function records: 
%  - audio data from soundcard's input
% In particular, 'nBlocks' of audio segments of size 'duration' are
% recorded and an image is taken every 'duration' seconds.
%
% duration: (in seconds) the duration of each audio segment
% nBlocks:   number of blocks to be recorded


% OPEN SOUNDCARD INPUT:      
ai = analoginput('winsound');
addchannel(ai,1);
Fs = 8000;
%NFFT = 16000 / 100;
set (ai, 'SampleRate', Fs);
set (ai, 'SamplesPerTrigger', duration*Fs);
Flag = 0;
numOfProcessedBlocks = 0;

for i=1:nBlocks
    % start recodring process:
    start(ai);
            
    % if at least one segment has been buffered:
    if ((i>1) && (Flag==1))        
        numOfProcessedBlocks = numOfProcessedBlocks + 1;        
        % re-sample (16KHz) the current segment:        
        tempX = imresize(x, [(16000/Fs)*length(x) 1]);                       
        time = (i-1)*duration+1/16000: 1/16000 :i*duration;        
       
        % plot current audio block:  
        Pl = plot(time, tempX); 
        axis([min(time) max(time) -1 1]);
        title('Current Audio Block');   
        xlabel('Time (s)');
        grid;

        y = abs(fft(tempX));
        y = y(1:length(tempX)/2);
        recog2 = dtmfrun4(y,40);
        str = num2str(recog2);
        msgbox(str,'Recognized Touch-tone');
    end
          
    if (strcmp(get(ai,'Running'),'On')==1)
        Flag = 1;
        x = getdata(ai, duration * Fs);              
    else
        Flag = 0;
        x = zeros(duration*Fs,1);
        fprintf('%30s\n','Problem reading input!!!!!!');
    end
    
end

% Step 5: Clean up
delete(ai);
clear ai

