function [keys] = dtmfrun2(xx,T,fs)
%DTMFRUN2 keys = dtmfrun2(xx,T,fs)
% returns the list of key names found in xx
% keys = array of characters, i.e., the decoded key name
% xx = DTMF waveform
% T = filter threshold
% fs = sampling freq

[nstart,nstop] = dtmfcut(xx,fs); %<--Find the tone bursts
keys = ''; %initializes keys
key = '';
length(nstart)

for kk=1:length(nstart) %cycle through each tone
    x_seg = xx(nstart(kk):nstop(kk)); %<--Extract one DTMF tone
    
%     key = dtmffilt(x_seg,T);
    y = abs(fft(x_seg));
    if(mod(length(y)/2,2)~=0)
        y = [y,0];
    end
    y = y(1:length(y)/2);
    noise = y(1:150);
    avg = mean(noise);
    stdv = std(noise);
    L = avg + 3*stdv;
%     plot(y)
    y = y - L;
    negvals = y < 0;
    y(negvals) = 0;
    
    %sampling at 8000Hz puts the freqencies in the corresponding bins
    %    1209 , 1336, 1477, 1633
    %697  '1' , '2' , '3' , 'A';
    %770  '4' , '5' , '6' , 'B';
    %852  '7' , '8' , '9' , 'C';
    %941  '*' , '0' , '#' , 'D';

    % Multiply frequencies by length(xx)/fs = .3 (round up)
    %NOISE TONES, scale by 5
    %     364 , 402 , 444 , 491
    %210  '1' , '2' , '3' , 'A';
    %232  '4' , '5' , '6' , 'B';
    %257  '7' , '8' , '9' , 'C';
    %284  '*' , '0' , '#' , 'D';

    %LAST TONE
    %     295 , 335 , 370 , 409
    %170  '1' , '2' , '3' , 'A';
    %194  '4' , '5' , '6' , 'B';
    %214  '7' , '8' , '9' , 'C';
    %236  '*' , '0' , '#' , 'D';

    %PRIOR TONES
    %     297 , 348 , 384 , 425
    %171  '1' , '2' , '3' , 'A';
    %201  '4' , '5' , '6' , 'B';
    %222  '7' , '8' , '9' , 'C';
    %245  '*' , '0' , '#' , 'D';

    %frequencies are fluctuating b/c of noise
    %need to create pass bands within reasonable range
    %need to scale passbands by number of tones <--dtmfcut was not parsing
    %need to change if statement paramenters (cannot use array) <--max()
    %get new freq passband from 5x noise, unless figure out parse 10x
%     figure
    plot(y)
    figure

    num = length(nstart);
%     if(max(y(175*num:210*num)) > T && max(y(303*num:364*num)) > T)
%         key = '1';
%     end
    if(max(y(170:210)) > T && max(y(295:364)) > T) %and last tone
        key = '1';
    end
    if(max(y(171:210)) > T && max(y(326:402)) > T)
        key = '2';
    end
%     if((y(182) > T && y(348) > T) || (y(175) > T && y(335) > T))
%         key = '2';
%     end
    if((y(182) > T && y(384) > T) || (y(175) > T && y(370)))
        key = '3';
    end
    if(y(210) > T && y(491) > T)
        key = 'A';
    end
    if(y(232) > T && y(364) > T)
        key = '4';
    end
    if(y(232) > T && y(402) > T)
        key = '5';
    end
    if(y(232) > T && y(444) > T)
        key = '6';
    end
    if(y(232) > T && y(491) > T)
        key = 'B';
    end
    if(y(257) > T && y(364) > T)
        key = '7';
    end
    if(y(257) > T && y(402) > T)
        key = '8';
    end
    if(y(257) > T && y(444) > T)
        key = '9';
    end
    if(y(257) > T && y(491) > T)
        key = 'C';
    end
    if(y(284) > T && y(364) > T)
        key = '*';
    end
    if(y(284) > T && y(402) > T)
        key = '0';
    end
    if(y(284) > T && y(444) > T)
        key = '#';
    end
    if(y(284) > T && y(491) > T)
        key = 'D';
    end
    
    
    keys = [keys,key];
end