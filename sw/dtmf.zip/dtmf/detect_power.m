function y=detect_power(dialed_number)
l=length(dialed_number);
start_index=find(dialed_number.^2~=0, 1 );
end_index=find((dialed_number(start_index:l)).^2==0,1);
y=[start_index end_index+start_index-2];
