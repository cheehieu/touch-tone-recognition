function varargout = gui(varargin)
% GUI M-file for gui.fig
%      GUI, by itself, creates a new GUI or raises the existing
%      singleton*.
%
%      H = GUI returns the handle to a new GUI or the handle to
%      the existing singleton*.
%
%      GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI.M with the given input arguments.
%
%      GUI('Property','Value',...) creates a new GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gui

% Last Modified by GUIDE v2.5 26-Apr-2010 08:16:31

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gui_OpeningFcn, ...
                   'gui_OutputFcn',  @gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gui is made visible.
function gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gui (see VARARGIN)

% Choose default command line output for gui
handles.output = hObject;
% Global variable to store dialed keypad values
handles.signal = 0;
handles.signal_str = '';
handles.noiseless_sig = 0;
handles.flag = 1;
handles.recording = 0;
guidata(hObject, handles);

% UIWAIT makes gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[one]=dtmfdial('1',8000);
soundsc(one);
handles.signal = [handles.signal,one];
handles.signal_str = [handles.signal_str,'1'];
set(handles.number_dialed,'String',handles.signal_str);

t = 0:1/8000:(length(handles.signal)-1)/8000;
plot(handles.graph,t,handles.signal);
title('DTMF Signal');
xlabel('Time (s)');
ylabel('Amplitude');
guidata(hObject, handles);


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[two]=dtmfdial('2',8000);
soundsc(two);
handles.signal = [handles.signal,two];
handles.signal_str = [handles.signal_str,'2'];
set(handles.number_dialed,'String',handles.signal_str);

t = 0:1/8000:(length(handles.signal)-1)/8000;
plot(handles.graph,t,handles.signal);
title('DTMF Signal');
xlabel('Time (s)');
ylabel('Amplitude');
guidata(hObject, handles);

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[three]=dtmfdial('3',8000);
soundsc(three);
handles.signal = [handles.signal,three];
handles.signal_str = [handles.signal_str,'3'];
set(handles.number_dialed,'String',handles.signal_str);

t = 0:1/8000:(length(handles.signal)-1)/8000;
plot(handles.graph,t,handles.signal);
title('DTMF Signal');
xlabel('Time (s)');
ylabel('Amplitude');
guidata(hObject, handles);

% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[four]=dtmfdial('4',8000);
soundsc(four);
handles.signal = [handles.signal,four];
handles.signal_str = [handles.signal_str,'4'];
set(handles.number_dialed,'String',handles.signal_str);

t = 0:1/8000:(length(handles.signal)-1)/8000;
plot(handles.graph,t,handles.signal);
title('DTMF Signal');
xlabel('Time (s)');
ylabel('Amplitude');
guidata(hObject, handles);


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[five]=dtmfdial('5',8000);
soundsc(five);
handles.signal = [handles.signal,five];
handles.signal_str = [handles.signal_str,'5'];
set(handles.number_dialed,'String',handles.signal_str);

t = 0:1/8000:(length(handles.signal)-1)/8000;
plot(handles.graph,t,handles.signal);
title('DTMF Signal');
xlabel('Time (s)');
ylabel('Amplitude');
guidata(hObject, handles);


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[six]=dtmfdial('6',8000);
soundsc(six);
handles.signal = [handles.signal,six];
handles.signal_str = [handles.signal_str,'6'];
set(handles.number_dialed,'String',handles.signal_str);

t = 0:1/8000:(length(handles.signal)-1)/8000;
plot(handles.graph,t,handles.signal);
title('DTMF Signal');
xlabel('Time (s)');
ylabel('Amplitude');
guidata(hObject, handles);


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[seven]=dtmfdial('7',8000);
soundsc(seven);
handles.signal = [handles.signal,seven];
handles.signal_str = [handles.signal_str,'7'];
set(handles.number_dialed,'String',handles.signal_str);

t = 0:1/8000:(length(handles.signal)-1)/8000;
plot(handles.graph,t,handles.signal);
title('DTMF Signal');
xlabel('Time (s)');
ylabel('Amplitude');
guidata(hObject, handles);


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[eight]=dtmfdial('8',8000);
soundsc(eight);
handles.signal = [handles.signal,eight];
handles.signal_str = [handles.signal_str,'8'];
set(handles.number_dialed,'String',handles.signal_str);

t = 0:1/8000:(length(handles.signal)-1)/8000;
plot(handles.graph,t,handles.signal);
title('DTMF Signal');
xlabel('Time (s)');
ylabel('Amplitude');
guidata(hObject, handles);


% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[nine]=dtmfdial('9',8000);
soundsc(nine);
handles.signal = [handles.signal,nine];
handles.signal_str = [handles.signal_str,'9'];
set(handles.number_dialed,'String',handles.signal_str);

t = 0:1/8000:(length(handles.signal)-1)/8000;
plot(handles.graph,t,handles.signal);
title('DTMF Signal');
xlabel('Time (s)');
ylabel('Amplitude');
guidata(hObject, handles);


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[ast]=dtmfdial('*',8000);
soundsc(ast);
handles.signal = [handles.signal,ast];
handles.signal_str = [handles.signal_str,'*'];
set(handles.number_dialed,'String',handles.signal_str);

t = 0:1/8000:(length(handles.signal)-1)/8000;
plot(handles.graph,t,handles.signal);
title('DTMF Signal');
xlabel('Time (s)');
ylabel('Amplitude');
guidata(hObject, handles);


% --- Executes on button press in pushbutton11.
function pushbutton11_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[zero]=dtmfdial('0',8000);
soundsc(zero);
handles.signal = [handles.signal,zero];
handles.signal_str = [handles.signal_str,'0'];
set(handles.number_dialed,'String',handles.signal_str);

t = 0:1/8000:(length(handles.signal)-1)/8000;
plot(handles.graph,t,handles.signal);
title('DTMF Signal');
xlabel('Time (s)');
ylabel('Amplitude');
guidata(hObject, handles);


% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[pnd]=dtmfdial('#',8000);
soundsc(pnd);
handles.signal = [handles.signal,pnd];
handles.signal_str = [handles.signal_str,'#'];
set(handles.number_dialed,'String',handles.signal_str);

t = 0:1/8000:(length(handles.signal)-1)/8000;
plot(handles.graph,t,handles.signal);
title('DTMF Signal');
xlabel('Time (s)');
ylabel('Amplitude');
guidata(hObject, handles);


% --- Executes on button press in pushbutton13.
function pushbutton13_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[A]=dtmfdial('A',8000);
soundsc(A);
handles.signal = [handles.signal,A];
handles.signal_str = [handles.signal_str,'A'];
set(handles.number_dialed,'String',handles.signal_str);

t = 0:1/8000:(length(handles.signal)-1)/8000;
plot(handles.graph,t,handles.signal);
title('DTMF Signal');
xlabel('Time (s)');
ylabel('Amplitude');
guidata(hObject, handles);


% --- Executes on button press in pushbutton14.
function pushbutton14_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[B]=dtmfdial('B',8000);
soundsc(B);
handles.signal = [handles.signal,B];
handles.signal_str = [handles.signal_str,'B'];
set(handles.number_dialed,'String',handles.signal_str);

t = 0:1/8000:(length(handles.signal)-1)/8000;
plot(handles.graph,t,handles.signal);
title('DTMF Signal');
xlabel('Time (s)');
ylabel('Amplitude');
guidata(hObject, handles);


% --- Executes on button press in pushbutton15.
function pushbutton15_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[C]=dtmfdial('C',8000);
soundsc(C);
handles.signal = [handles.signal,C];
handles.signal_str = [handles.signal_str,'C'];
set(handles.number_dialed,'String',handles.signal_str);

t = 0:1/8000:(length(handles.signal)-1)/8000;
plot(handles.graph,t,handles.signal);
title('DTMF Signal');
xlabel('Time (s)');
ylabel('Amplitude');
guidata(hObject, handles);


% --- Executes on button press in pushbutton16.
function pushbutton16_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[D]=dtmfdial('D',8000);
soundsc(D);
handles.signal = [handles.signal,D];
handles.signal_str = [handles.signal_str,'D'];
set(handles.number_dialed,'String',handles.signal_str);

t = 0:1/8000:(length(handles.signal)-1)/8000;
plot(handles.graph,t,handles.signal);
title('DTMF Signal');
xlabel('Time (s)');
ylabel('Amplitude');
guidata(hObject, handles);


function number_to_dial_Callback(hObject, eventdata, handles)
% hObject    handle to number_to_dial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of number_to_dial as text
%        str2double(get(hObject,'String')) returns contents of number_to_dial as a double


% --- Executes on button press in dial.
function dial_Callback(hObject, eventdata, handles)
% hObject    handle to dial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
dialnum_str = get(handles.number_to_dial,'String');
[handles.signal] = dtmfdial(dialnum_str, 8000);
soundsc(handles.signal);
t = 0:1/8000:(length(handles.signal)-1)/8000;
plot(handles.graph,t,handles.signal);
title('DTMF Signal');
xlabel('Time (s)');
ylabel('Amplitude');
set(handles.number_dialed,'String',dialnum_str);
guidata(hObject, handles);


function seconds_Callback(hObject, eventdata, handles)
% hObject    handle to seconds (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of seconds as text
%        str2double(get(hObject,'String')) returns contents of seconds as a double


% --- Executes during object creation, after setting all properties.
function seconds_CreateFcn(hObject, eventdata, handles)
% hObject    handle to seconds (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in record.
function record_Callback(hObject, eventdata, handles)
% hObject    handle to record (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Fs = 8000;
sec = str2double(get(handles.seconds,'String'));
disp('Start recording...')
handles.recording = wavrecord(sec*Fs,Fs,'double');
disp('End recording.')
handles.signal = handles.recording;
set(handles.record,'BackgroundColor', [.49 .49 .49]);
set(handles.play,'BackgroundColor', [.94 .94 .94]);
set(handles.dial_rec,'BackgroundColor', [.94 .94 .94]);
guidata(hObject, handles);


% --- Executes on button press in play.
function play_Callback(hObject, eventdata, handles)
% hObject    handle to play (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
plot(handles.graph,handles.signal);
title('DTMF Signal');
xlabel('Time (s)');
ylabel('Amplitude');
wavplay(handles.signal,8000);
set(handles.record,'BackgroundColor', [.94 .94 .94]);
set(handles.play,'BackgroundColor', [.49 .49 .49]);
set(handles.dial_rec,'BackgroundColor', [.94 .94 .94]);
guidata(hObject, handles);


% --- Executes on button press in dial_rec.
function dial_rec_Callback(hObject, eventdata, handles)
% hObject    handle to dial_rec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% recog = norm_recognize(get(handles.number_dialed,'String'),str2double(get(handles.noise_level,'String'))/10);
% set(handles.recognized_text,'String',num2str(recog));

if(mod(length(handles.signal),2) == 1)
    handles.signal = [handles.signal,0];
end
t = 0:length(handles.signal)-1;
t = 8000/length(handles.signal)*t;
t = t(1:length(handles.signal)/2);
y = abs(fft(handles.signal));
y = y(1:length(handles.signal)/2);
plot(handles.graph,y); %t
title('DTMF Signal');
xlabel('Frequency (Hz)');
ylabel('Amplitude');
recog2 = dtmfrun3(y,45);
set(handles.recognized_text,'String',num2str(recog2));
grid

set(handles.record,'BackgroundColor', [.94 .94 .94]);
set(handles.play,'BackgroundColor', [.94 .94 .94]);
set(handles.dial_rec,'BackgroundColor', [.49 .49 .49]);
guidata(hObject, handles);


% --- Executes on button press in recognize.
function recognize_Callback(hObject, eventdata, handles)
% hObject    handle to recognize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%for x=1:5000
%    stopBar= progressbar(x/5000,0);
%    if (stopBar) break; end
%end
% msgbox(recog,'Recognized Touch-tone');
%[m,n] = fourierSeries(handles.signal);
%t = (0+3)/length(handles.signal_str):1540/463.4/length(handles.signal_str):((length(m)*1540-1540)/463.4+3)/length(handles.signal_str);

% recog = dtmfrun(handles.signal,100,8000);
recog = norm_recognize(get(handles.number_dialed,'String'),str2double(get(handles.noise_level,'String'))/10);
set(handles.recognized_text,'String',num2str(recog));

if(mod(length(handles.signal),2) == 1)
    handles.signal = [handles.signal,0];
end
t = 0:length(handles.signal)-1;
t = 8000/length(handles.signal)*t;
t = t(1:length(handles.signal)/2);
y = abs(fft(handles.signal));
y = y(1:length(handles.signal)/2);
plot(handles.graph,t,y);
title('DTMF Signal');
xlabel('Frequency (Hz)');
ylabel('Amplitude');
grid
guidata(hObject, handles);


% --- Executes on button press in filter.
function filter_Callback(hObject, eventdata, handles)
% hObject    handle to filter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% soundsc(handles.signal);
% handles.signal = handles.noiseless_sig;
% t = 0:1/8000:(length(handles.signal)-1)/8000;
% plot(handles.graph,t,handles.signal);
% title('DTMF Signal');
% xlabel('Time (s)');
% ylabel('Amplitude');
figure;
norm_filter(get(handles.number_dialed,'String'),str2double(get(handles.noise_level,'String'))/10);
guidata(hObject, handles);

% --- Executes on button press in noise.
function noise_Callback(hObject, eventdata, handles)
% hObject    handle to noise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of noise
%noise = 0, if the box is unchecked, 
%noise = 1, if the box is checked
noisecheck = get(handles.noise,'Value');
if(noisecheck)
    %if box is checked, add noise
    if(handles.flag)
        handles.noiseless_sig = handles.signal;
        handles.flag = 0;
    end
    noise_scale = str2double(get(handles.noise_level,'String'))/10;
    y = rand(size(handles.signal))-0.5;
    handles.signal = handles.noiseless_sig + noise_scale * y;
end
guidata(hObject, handles);


function noise_level_Callback(hObject, eventdata, handles)
% hObject    handle to noise_level (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of noise_level as text
%        str2double(get(hObject,'String')) returns contents of noise_level as a double


% --- Executes on slider movement.
function noise_slider_Callback(hObject, eventdata, handles)
% hObject    handle to noise_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of
%        slider
noiseValue = get(handles.noise_slider,'Value');%obtains the slider value from the slider component
set(handles.noise_level,'String', num2str(noiseValue));%puts the slider value into the edit text component
set(handles.noise,'Value', 0.0);
guidata(hObject, handles);% Update handles structure


% --- Executes on button press in play_noise.
function play_noise_Callback(hObject, eventdata, handles)
% hObject    handle to play_noise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
noisecheck = get(handles.noise,'Value');
if(noisecheck)
    soundsc(handles.signal);
    t = 1:length(handles.signal);
    plot(handles.graph,t,handles.signal);
else
    if(handles.flag)
        soundsc(handles.signal);
        t = 0:1/8000:(length(handles.noiseless_sig)-1)/8000;
        plot(handles.graph,t,handles.signal);
    else
        soundsc(handles.noiseless_sig);
        t = 0:1/8000:(length(handles.noiseless_sig)-1)/8000;
        plot(handles.graph,t,handles.noiseless_sig);
    end
end
title('DTMF Signal');
xlabel('Time (s)');
ylabel('Amplitude');
guidata(hObject, handles);


% --- Executes on button press in clear.
function clear_Callback(hObject, eventdata, handles)
% hObject    handle to clear (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.signal = 0;
handles.noiseless_sig = 0;
handles.flag = 1;
t = 0:1/8000:(length(handles.signal)-1)/8000;
plot(handles.graph,t,handles.signal);
title('DTMF Signal');
xlabel('Time (s)');
ylabel('Amplitude');
handles.signal_str = '';
set(handles.number_dialed,'String',handles.signal_str);
set(handles.recognized_text,'String',handles.signal_str);
guidata(hObject, handles);


% --- Executes on button press in realtime.
function realtime_Callback(hObject, eventdata, handles)
% hObject    handle to realtime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
str = realTimeMic2(1,100);
set(handles.recognized_text,'String',str);