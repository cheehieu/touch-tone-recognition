function [xx_filt] = dtmffilt(xx,fs)
%DTMFFILT keys = dtmffilt(xx,T,fs)
% returns the list of key names found in xx
% keys = array of characters, i.e., the decoded key name
% x_seg = one DTMF tone
% T = filter threshold

y = abs(xx);
noise = y(1:401);
avg = mean(noise);
stdv = std(noise);
L = avg + 3*stdv;
y = y - L;
negvals = y < 0;
y(negvals) = 0;
y = y(:)'/max(abs(y));%normalize
%try to replicate original signal (convolve negative)
xx_filt = y;