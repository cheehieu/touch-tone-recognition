function y = dtmf_encoder(r,c,T,noisescale)
global fs
t = linspace(0, T, fs*T);
if (r==0) && (c==0)
    y = 0;
else
y = cos(2*pi*r*t)+cos(2*pi*c*t);
y = y + noisescale*(rand(size(y)) - .5);
end

