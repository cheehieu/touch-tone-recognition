% clear all; close all; clc

global fs T fr fc 

fs=8000;                                      % Sampling Frequency is 8 KHz
T=100e-3;                                                  %Signal Duration
Tp=40e-3;                                                       %Pause time
Pause_Signal=zeros(1,Tp*fs);

fr=[697 770 852 941];                                     % Row Frequencies
fc=[1209 1336 1477 1633];                              % Column Frequencies

digits_entry=input('Enter digits to dial: ','s');
l=length(digits_entry);

dialed_number=Pause_Signal;
for i=1:l
    d=digits_entry(i);
    switch d
        case '1'
            r=fr(1);c=fc(1);
        case '2'
            r=fr(1);c=fc(2);
        case '3'
            r=fr(1);c=fc(3);
        case 'A'
            r=fr(1);c=fc(4);
        case '4'
            r=fr(2);c=fc(1);
        case '5'
            r=fr(2);c=fc(2);
        case '6'
            r=fr(2);c=fc(3);
        case 'B'
            r=fr(2);c=fc(4);
        case '7'
            r=fr(3);c=fc(1);
        case '8'
            r=fr(3);c=fc(2);
        case '9'
            r=fr(3);c=fc(3);
        case 'C'
            r=fr(3);c=fc(4);
        case '*'
            r=fr(4);c=fc(1);
        case '0'
            r=fr(4);c=fc(2);
        case '#'
            r=fr(4);c=fc(3);
        case 'D'
            r=fr(4);c=fc(4);
        otherwise
            r=0;c=0;
    end
    encoded_digit=dtmf_encoder(r,c,T)/2;
    dialed_number=[dialed_number, encoded_digit, Pause_Signal];
end
% soundsc(dialed_number, fs);
wavwrite(dialed_number,fs,'dialed');
ld=length(dialed_number);
save dld dialed_number

% 
% figure(1)
% plot((0:ld-1)/fs,dialed_number);
% 
% figure(2)
% a=fftshift(fft(dialed_number));
% f=linspace(-fs/2,fs/2,length(a));
% plot(f, abs(a));
% 
% figure(3)
% plot(f, abs(a));
% axis([0 2000 0 max(abs(a))*1.1])
% grid
            
