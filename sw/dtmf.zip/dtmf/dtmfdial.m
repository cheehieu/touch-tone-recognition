function xx = dtmfdial(keyNames,fs)
%DTMFDIAL Create a signal vector of tones which will dial
% a DTMF (Touch Tone) telephone system.
%
% usage: xx = dtmfdial(keyNames,fs)
% keyNames = vector of characters containing valid key names
% fs = sampling frequency
% xx = signal vector that is the concatenation of DTMF tones.
%
dtmf.keys = ... %defines keys matrix
['1','2','3','A';
 '4','5','6','B';
 '7','8','9','C';
 '*','0','#','D'];
dtmf.colTones = ones(4,1)*[1209,1336,1477,1633]; %defines cols matrix
dtmf.rowTones = [697;770;852;941]*ones(1,4); %defines rows matrix
dur = .25; % defines duration of each tone
tt = 0:1/fs:dur; %creates time vector based on duration
xx = 0; % initializes xx for concatonation
for ii = 1:length(keyNames) %cycles through each inputted keyname
    keyName = keyNames(ii); %provides a single variable to the current keyname
    if (keyName~='1' && keyName~='2' && keyName~='3' && keyName~='A' && keyName~='4' && keyName~='5' && keyName~='6' && keyName~='B' && keyName~='7' && keyName~='8' && keyName~='9' && keyName~='C' && keyName~='#' && keyName~='0' && keyName~='*' && keyName~='D')
        %skips the rest of the code if key is invalid
        continue
    end;
    [r,c] = find(dtmf.keys==keyName); %determines row an col of the keyname
    tone = cos(2*pi*dtmf.rowTones(r,c)*tt) + cos(2*pi*dtmf.colTones(r,c)*tt);
    % sums the two frequency components found using the row and col from find
    xx = [xx,zeros(1,.05*fs),tone]; % concatonates the current output, zeros,
                                    % and the new tone.
end