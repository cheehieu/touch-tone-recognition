function y=map_freq(ir,ic)
t=0;
if ir==1
    switch ic
        case 1
            t=1;
        case 2
            t=2;
        case 3
            t=3;
    end
end

if ir==2
    switch ic
        case 1
            t=4;
        case 2
            t=5;
        case 3
            t=6;
    end
end

if ir==3
    switch ic
        case 1
            t=7;
        case 2
            t=8;
        case 3
            t=9;
    end
end

if ir==4
    switch ic
        case 1
            t=0;
        case 2
            t=0;
        case 3
            t=0;
    end
end

y=t;
end
