function norm_filter(xx_str,noisescale)

global fs T fr fc 
keys = '';

fs=8000;                                      % Sampling Frequency is 8 KHz
T=100e-3;                                                  %Signal Duration
Tp=40e-3;                                                       %Pause time
Pause_Signal=zeros(1,Tp*fs);

fr=[697 770 852 941];                                     % Row Frequencies
fc=[1209 1336 1477 1633];                              % Column Frequencies

l=length(xx_str);

dialed_number=Pause_Signal;
for i=1:l
    d=xx_str(i);
    switch d
        case '1'
            r=fr(1);c=fc(1);
        case '2'
            r=fr(1);c=fc(2);
        case '3'
            r=fr(1);c=fc(3);
        case 'A'
            r=fr(1);c=fc(4);
        case '4'
            r=fr(2);c=fc(1);
        case '5'
            r=fr(2);c=fc(2);
        case '6'
            r=fr(2);c=fc(3);
        case 'B'
            r=fr(2);c=fc(4);
        case '7'
            r=fr(3);c=fc(1);
        case '8'
            r=fr(3);c=fc(2);
        case '9'
            r=fr(3);c=fc(3);
        case 'C'
            r=fr(3);c=fc(4);
        case '*'
            r=fr(4);c=fc(1);
        case '0'
            r=fr(4);c=fc(2);
        case '#'
            r=fr(4);c=fc(3);
        case 'D'
            r=fr(4);c=fc(4);
        otherwise
            r=0;c=0;
    end
    encoded_digit=dtmf_encoder(r,c,T,noisescale)/2;
    dialed_number=[dialed_number, encoded_digit, Pause_Signal];
end
wavwrite(dialed_number,fs,'dialed');
ld=length(dialed_number);
save dld dialed_number


n=20;                                          % Filter Order
fs=8000;
min_tone_duration=50e-3;

wn1=[0.17 0.18];
b1=fir1(n,wn1);

wn2=[0.1875 0.1975];
b2=fir1(n,wn2);

wn3=[0.2075 0.2175];
b3=fir1(n,wn3);

wn4=[0.23 0.24];
b4=fir1(n,wn4);

wn5=[0.2975 0.3025];
b5=fir1(n,wn5);

wn6=[0.3287 0.3388];
b6=fir1(n,wn6);

wn7=[0.3638 0.3738];
b7=fir1(n,wn7);

wn8=[0.4038 0.4138];
b8=fir1(n,wn8);

subplot 421
ff=fftshift(abs(fft(b1, fs)));
plot((-fs/2+1:fs/2),ff)
grid

subplot 422
ff=fftshift(abs(fft(b2, fs)));
plot((-fs/2+1:fs/2),ff)
grid

subplot 423
ff=fftshift(abs(fft(b3, fs)));
plot((-fs/2+1:fs/2),ff)
grid

subplot 424
ff=fftshift(abs(fft(b4, fs)));
plot((-fs/2+1:fs/2),ff)
grid

subplot 425
ff=fftshift(abs(fft(b5, fs)));
plot((-fs/2+1:fs/2),ff)
grid

subplot 426
ff=fftshift(abs(fft(b6, fs)));
plot((-fs/2+1:fs/2),ff)
grid

subplot 427
ff=fftshift(abs(fft(b7, fs)));
plot((-fs/2+1:fs/2),ff)
grid

subplot 428
ff=fftshift(abs(fft(b8, fs)));
plot((-fs/2+1:fs/2),ff)
grid

load dld


l=length(dialed_number);
while l>=min_tone_duration*fs
    l=length(dialed_number);
    ise=detect_power(dialed_number);
    y=signal_to_digit(dialed_number(ise(1):ise(2)));
    key = num2str(map_freq(y(1),y(2)));
    keys = [keys,key];
    dialed_number=dialed_number(ise(2)+1:l);
    l=length(dialed_number);
end

y1=filter(b1,1,dialed_number);
y2=filter(b2,1,dialed_number);
y3=filter(b3,1,dialed_number);
y4=filter(b4,1,dialed_number);
y5=filter(b5,1,dialed_number);
y6=filter(b6,1,dialed_number);
y7=filter(b7,1,dialed_number);
y8=filter(b8,1,dialed_number);
